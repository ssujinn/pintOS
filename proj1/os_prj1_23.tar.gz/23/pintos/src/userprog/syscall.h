#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
#include "lib/user/syscall.h"

void syscall_init (void);
int fibonacci (int n);
int sum_of_four_int (int a, int b, int c, int d);

#endif /* userprog/syscall.h */
