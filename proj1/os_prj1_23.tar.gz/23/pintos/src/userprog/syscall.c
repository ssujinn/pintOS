#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "devices/shutdown.h"
#include "userprog/exception.h"
#include "userprog/process.h"

static void syscall_handler (struct intr_frame *);

void halt (void);
void exit (int status);
pid_t exec (const char *cmd_line);
int wait (pid_t pid);
int read (int fd, void *buffer, unsigned size);
int write (int fd, const void *buffer, unsigned size);

void
syscall_init (void) 
{
  //printf("syscall 들어가냐\n\n\n");
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
  //printf("syscall init 끝남\n\n\n");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  int *sc_num = f->esp;

  if (!is_user_vaddr(sc_num))
    exit(-1);
 // printf("handler 등자ㅏ아아아앙아아ㅏ아앙\n\n\n\n\n\n\n");
 // printf("syscall number: %d\n", *sc_num);
  //printf("%s\n",f->esp);
  //hex_dump(f->esp,f->esp,100,true);
  switch(*sc_num){
    case 0:
      halt();
      break;

    case 1:
      if (!is_user_vaddr(&sc_num[1]))
        exit(-1);
      exit(sc_num[1]);
      break;

    case 2:
      if (!is_user_vaddr(&sc_num[1]))
        exit(-1);
      f->eax = (uint32_t)exec((const char*)sc_num[1]);
      break;

    case 3:
      if (!is_user_vaddr(&sc_num[1]))
        exit(-1);
      f->eax = (uint32_t)wait((pid_t)sc_num[1]);
      break;

    case 8:
      if (!is_user_vaddr(&sc_num[1]) || !is_user_vaddr(&sc_num[2]) || !is_user_vaddr(&sc_num[3]))
        exit(-1);

      f->eax = (uint32_t)read((int)sc_num[1], (void *)sc_num[2], (unsigned)sc_num[3]);
      break;

    case 9:
      if (!is_user_vaddr(&sc_num[1]) || !is_user_vaddr(&sc_num[2]) || !is_user_vaddr(&sc_num[3]))

        exit(-1);

      f->eax = (uint32_t)write((int)sc_num[1], (const void *)sc_num[2], (unsigned)sc_num[3]);
      break;

    case 13:
      if (!is_user_vaddr(&sc_num[1]))
        exit(-1);

      f->eax = (uint32_t)fibonacci((int)sc_num[1]);
      break;

    case 14:
      if (!is_user_vaddr(&sc_num[1]) || !is_user_vaddr(&sc_num[2]) || !is_user_vaddr(&sc_num[3]) || !is_user_vaddr(&sc_num[4]))
        exit(-1);

      //printf("SUMTHING~~~~~~\n\n\n\n\n\n\n\n");
      f->eax = (uint32_t)sum_of_four_int((int)sc_num[1], (int)sc_num[2], (int)sc_num[3], (int)sc_num[4]);
      break;

    default:
      //printf("system call!\n");
      thread_exit();
      break;
  }
}


void 
halt (void){
  shutdown_power_off();
}

void 
exit (int status){
 // printf("%d\n\n\n",status);
  struct thread *cur;
  cur = thread_current();
  cur->is_end = 1;
  cur->exit_status = status;
  list_remove(&(cur->child_elem));
  printf("%s: exit(%d)\n", cur->name, cur->exit_status);

  if (cur->parent)
    cur->parent->exit_status = cur->exit_status;
 // printf("%s: exit(%d)\n", cur->name, cur->exit_status);
    thread_exit();
  //printf("여기서 status : %d\n\n\n", cur->exit_status);
}

pid_t 
exec (const char *cmd_line){
  pid_t cpid;
  cpid = process_execute(cmd_line);
  /*
  int i = 0;
  struct list_elem *find;
  find = list_begin(&(thread_current()->child));
  struct thread *thread_child = thread_current();
  int size = list_size(&(thread_current()->child));
  while (1){
    if (i == size)
      return -1;
    thread_child = list_entry(find, struct thread, child_elem);
    if (thread_child -> tid == cpid)
      break;
    find = list_next(find);
    i++;
  }

  //sema_down(&(thread_child->parent->sema_load));
*/
  return cpid;
}

int 
wait (pid_t pid){
  return process_wait(pid);
}

int 
read (int fd, void *buffer, unsigned size){ 
  int i;

  if (fd != 0)
    return -1;

  for (i = 0; i < size; i++)
    if (((uint8_t*)buffer)[i] == 0)
      break;
  return i;
 }

int 
write (int fd, const void *buffer, unsigned size){  
  if (fd != 1)
    return -1;

  putbuf((char *)buffer, size);  
  return size;
}

/*---------------additional system calls-------------------------*/
int fibonacci(int n){
  int f0 = 0, f1 = 1, fn = 0, i = 0;

  if (n <= 0)
    return f0;
  else if (n == 1)
    return f1;

  while (i < n - 1){
    fn = f0 + f1;
    f0 = f1;
    f1 = fn;
    i++;
  }

  return fn;
}

int sum_of_four_int(int a, int b, int c, int d){
  int sum = 0;

  sum += a;
  sum += b;
  sum += c;
  sum += d;
  return sum;
}
