#include "userprog/syscall.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "devices/input.h"
#include "devices/shutdown.h"
#include "userprog/exception.h"
#include "userprog/process.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "threads/synch.h"
#include "filesys/off_t.h"

struct file
{
  struct inode *inode;
  off_t pos;
  bool deny_write;
};

struct lock wrtlock;
struct lock mutexlock;
int readNum = 0;

static void syscall_handler(struct intr_frame *);
void halt (void);
void exit (int status);
pid_t exec (const char *cmd_line);
int wait (pid_t pid);
bool create(const char *file, unsigned initial_size);
bool remove(const char *file);
int open (const char *name);
int filesize(int fd);
int read (int fd, void *buffer, unsigned size);
int write (int fd, const void *buffer, unsigned size);
void seek (int fd, unsigned position);
unsigned tell( int fd);
void close (int fd);


void
syscall_init (void) 
{
  lock_init(&mutexlock);
  lock_init(&wrtlock);
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  int *sc_num = f->esp;

  if (!is_user_vaddr(sc_num)){
    exit(-1);
  }
  switch(*sc_num){
    case 0:
      halt();
      break;

    case 1:
      if (!is_user_vaddr(&sc_num[1]))
        exit(-1);
      exit(sc_num[1]);
      break;

    case 2:
      if (!is_user_vaddr(&sc_num[1]))
        exit(-1);
      f->eax = (uint32_t)exec((const char*)sc_num[1]);
      break;

    case 3:
      if (!is_user_vaddr(&sc_num[1]))
        exit(-1);
      f->eax = (uint32_t)wait((pid_t)sc_num[1]);
      break;
    
    case 4:
      if (!is_user_vaddr(&sc_num[1])||!is_user_vaddr(&sc_num[2]))
        exit(-1);
      f->eax = (uint32_t)create((const char*)sc_num[1], (unsigned)sc_num[2]);
      break;

    case 5:
      if (!is_user_vaddr(&sc_num[1]))
        exit(-1);
      f->eax = (uint32_t)remove((const char*)sc_num[1]);
      break;

    case 6:
      if (!is_user_vaddr(&sc_num[1]))
        exit(-1);
      f->eax = (uint32_t)open((const char*)sc_num[1]);
      break;

    case 7:  
      if (!is_user_vaddr(&sc_num[1]))
        exit(-1);
      f->eax = (uint32_t)filesize((int)sc_num[1]);
      break;

    case 8:
      if (!is_user_vaddr(&sc_num[1]) || !is_user_vaddr(&sc_num[2]) || !is_user_vaddr(&sc_num[3]))
        exit(-1);

      f->eax = (uint32_t)read((int)sc_num[1], (void *)sc_num[2], (unsigned)sc_num[3]);
      break;

    case 9:
      if (!is_user_vaddr(&sc_num[1]) || !is_user_vaddr(&sc_num[2]) || !is_user_vaddr(&sc_num[3]))

        exit(-1);

      f->eax = (uint32_t)write((int)sc_num[1], (const void *)sc_num[2], (unsigned)sc_num[3]);
      break;
      
    case 10:
      if (!is_user_vaddr(&sc_num[1])||!is_user_vaddr(&sc_num[2]))
        exit(-1);
      seek((int)sc_num[1], (unsigned)sc_num[2]);
      break;
      
    case 11:
      if (!is_user_vaddr(&sc_num[1]))
        exit(-1);
      f->eax=tell((int)sc_num[1]);
      break;
    
    case 12:
      if (!is_user_vaddr(&sc_num[1]))
        exit(-1);
      close((int)sc_num[1]);
      break;

    case 13:
      if (!is_user_vaddr(&sc_num[1]))
        exit(-1);
      f->eax = (uint32_t)fibonacci((int)sc_num[1]);
      break;

    case 14:
      if (!is_user_vaddr(&sc_num[1]) || !is_user_vaddr(&sc_num[2]) || !is_user_vaddr(&sc_num[3]) || !is_user_vaddr(&sc_num[4]))
        exit(-1);
      f->eax = (uint32_t)sum_of_four_int((int)sc_num[1], (int)sc_num[2], (int)sc_num[3], (int)sc_num[4]);
      break;
     

    default:
      exit(-1);
      break;
  }
}

/*-----------------------project1: userprog(1)--------------------------*/

void 
halt (void){
  shutdown_power_off();
}

void 
exit (int status){
  struct thread *cur;
  int i;
  cur = thread_current();
  cur->exit_status = status;
  cur->is_end = 1;
  printf("%s: exit(%d)\n", cur->name, cur->exit_status);

  for (i = 3; i < 130; i++){
    if (thread_current()->file[i])
      close(i);
  }

  thread_exit();
}

pid_t 
exec (const char *cmd_line){
  pid_t cpid;

  cpid = process_execute(cmd_line);
  return cpid;
}

int 
wait (pid_t pid){
  return process_wait(pid);
}

int 
read (int fd, void *buffer, unsigned size){ 
  int i;
  int readSize = -1;
  struct thread* cur=thread_current();

  if(buffer == NULL){
    exit(-1);
    return -1;
  }

  if(!is_user_vaddr(buffer)){
    exit(-1);
    return -1;
  }

  lock_acquire(&mutexlock);
  readNum++;
  if (readNum == 1)
    lock_acquire(&wrtlock);

  if (fd == 0){
    for (i = 0; i < (int)size; i++){
      ((uint8_t*)buffer)[i] = input_getc();
      if (((uint8_t*)buffer)[i] == 0)
        break;
    }
    readNum--;
    if (readNum == 0)
      lock_release(&wrtlock);
    lock_release(&mutexlock);

    return i;
  }
  else if (fd >= 3 && cur->file[fd]){
    readSize = file_read(cur->file[fd], buffer, size); 
  }

  readNum--;
  if (readNum == 0)
    lock_release(&wrtlock);
  lock_release(&mutexlock);

  if (fd >= 3 && readSize == -1)
    exit(-1);

  return readSize;
 }

int 
write (int fd, const void *buffer, unsigned size){  
  int wrtsize = -1;
  struct thread *cur=thread_current();

  if(!is_user_vaddr(buffer))
    exit(-1);

  lock_acquire(&wrtlock);

  if (fd == 1){
    putbuf(buffer, size);  
    wrtsize = size;
  }
  else if (fd > 2 && cur->file[fd]){
     if(cur->file[fd]->deny_write == true)
        file_deny_write(cur->file[fd]);
    wrtsize = file_write(cur->file[fd], buffer, size);
  }

  lock_release(&wrtlock);

  if (wrtsize == -1)
    exit(-1);

  return wrtsize;
}

/*---------------------additional system calls-------------------------*/
int
fibonacci (int n){
  int f0 = 0, f1 = 1, fn = 0, i = 0;

  if (n <= 0)
    return f0;
  else if (n == 1)
    return f1;

  while (i < n - 1){
    fn = f0 + f1;
    f0 = f1;
    f1 = fn;
    i++;
  }

  return fn;
}

int 
sum_of_four_int (int a, int b, int c, int d){
  int sum = 0;

  sum += a;
  sum += b;
  sum += c;
  sum += d;
  return sum;
}

/*-----------------------project2: userprog(2)--------------------------*/

bool 
create (const char *file, unsigned initial_size){
  if(file == NULL){
    exit(-1);
    return 0;
  }
  return filesys_create(file, initial_size);
}

bool
remove (const char *file){
  if (file == NULL){
    exit(-1);
    return 0;
  }
  return filesys_remove(file);
}

int 
open (const char *file){
  struct thread *cur = thread_current();
  struct file *fp;
  int i, state = 0, errorflag = 0;

  if(file == NULL){
    exit(-1);
    return -1;
  }

  lock_acquire(&wrtlock);

  fp = filesys_open(file);
  if (fp){
    for (i = 3; i < 130; i++){
      if (cur->file[i] == NULL){
        state = i;
        cur->file[i] = fp;
        if (!strcmp(file, cur->name))
          file_deny_write(fp);
        break;
      }
    }
  }
  else
    errorflag = 1;

  lock_release(&wrtlock);

  if (errorflag)
    state = -1;

  return state;
}

int 
filesize (int fd){
  struct thread *cur = thread_current();
  return file_length(cur->file[fd]);
}

void 
seek (int fd, unsigned position){
  struct thread *cur = thread_current(); 
  file_seek(cur->file[fd], position);
}

unsigned 
tell (int fd){
  struct thread *cur = thread_current();
  return file_tell(cur->file[fd]);
}

void 
close (int fd){
  struct thread *cur = thread_current();
  struct file *fp = cur->file[fd];

  if(cur->file[fd] == NULL)
    exit(-1);
  cur->file[fd] = NULL;
  file_close(fp);
}

