#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "list.h"
#include "hash.h"
#include "bitmap.h"


// struct
struct list_item{
	struct list_elem elem;
	int data;
};

struct hash_item{
	struct hash_elem elem;
	int data;
};

// list global variable
char list_name[10][10];
struct list list_var[10];
int list_cnt = 0;

// hash global variable
char hash_name[10][10];
struct hash hash_var[10];
int hash_cnt = 0;

// bitmap global variable
char bitmap_name[10][10];
int bitmap_cnt = 0;


// function
// user define
void editcmd(char *, char *, char *);
int list_name_check(char *);
int hash_name_check(char *);
int bitmap_name_check(char *);

// list fuction
bool list_less(const struct list_elem *, const struct list_elem *, void *);
void list_swap(struct list_elem *, struct list_elem *);
void list_shuffle(struct list *list);

// hash function
unsigned hash_hash(const struct hash_elem *, void *);
bool hash_less(const struct hash_elem *, const struct hash_elem *, void *);
void hash_destructor(struct hash_elem *, void *);
void hash_square(struct hash_elem *, void *);
void hash_triple(struct hash_elem *, void *);
unsigned hash_int_2(int);


// bitmap function
struct bitmap *bitmap_expand(struct bitmap *, int);
