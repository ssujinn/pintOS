#include "main.h"

struct bitmap *bit_var[10];

void main() {
	char cmd[100], inst[100], par[100];
	char par1[100], par2[100], par3[100];
	int idx1, idx2, idx3, val;
	int num, boolval;
	int i, j;

	while (1) {
		memset(cmd, '\0', sizeof(cmd));
		memset(inst, '\0', sizeof(inst));
		memset(par, '\0', sizeof(par));
		memset(cmd, '\0', sizeof(par1));
		memset(inst, '\0', sizeof(par2));
		memset(par, '\0', sizeof(par3));


		fgets(cmd, sizeof(cmd), stdin);

		editcmd(cmd, inst, par);

		// create
		if (!strcmp(inst, "create")) {
			num = sscanf(par, "%s %s %d", par1, par2, &val);
			if (num == 2){
				if (!strcmp(par1, "list")){
					strcpy(list_name[list_cnt], par2);
					list_init(&list_var[list_cnt]);
					list_cnt++;

				}
				else if (!strcmp(par1, "hashtable")){
					strcpy(hash_name[hash_cnt], par2);
					hash_init(&hash_var[hash_cnt], hash_hash, hash_less, NULL);
					hash_cnt++;
				}
			}
			else if (num == 3){
				if (!strcmp(par1, "bitmap")){
					strcpy(bitmap_name[bitmap_cnt], par2);
					bit_var[bitmap_cnt] = bitmap_create(val);
					bitmap_cnt++;
				}
			}

		}

		// delete
		else if (!strcmp(inst, "delete")) {
			num = sscanf(par, "%s", par1);
			if (num == 1){
				i = list_name_check(par1);
				if (i != list_cnt){
					while(1){
						if (list_empty(&list_var[i]))
						break;

						struct list_elem *deltmp;
						deltmp = list_pop_back(&list_var[i]);
						free(deltmp);
					}
					list_cnt--;
					continue;	
				}
				i = hash_name_check(par1);
				if (i != hash_cnt){
					hash_destroy(&hash_var[i], hash_destructor);
					hash_cnt--;
					continue;
				}
				i = bitmap_name_check(par1);
				if (i != bitmap_cnt){
					bitmap_destroy(bit_var[i]);
					bitmap_cnt--;
				}
			}

		}

		// print elements
		else if (!strcmp(inst, "dumpdata")) {
			num = sscanf(par, "%s", par1);
			if (num == 1){
				i = list_name_check(par1);
				if (i != list_cnt && !(list_empty(&list_var[i]))){
					struct list_elem *tmp = list_head(&list_var[i]);
					struct list_item *itemtmp;
					while(1){
						tmp = list_next(tmp);
						if (tmp == list_end(&list_var[i]))
							break;
						itemtmp = list_entry(tmp, struct list_item, elem);
						printf("%d ", itemtmp->data);					}
					printf("\n");
					continue;
				}

				i = hash_name_check(par1);
				if (i != hash_cnt && !(hash_empty(&hash_var[i]))){
					struct hash_item *hashdump;
					struct hash_iterator cur;

					hash_first(&cur, &hash_var[i]);
					while(1){
						if (!hash_next(&cur))
							break;
						hashdump = hash_entry(hash_cur(&cur), struct hash_item, elem);
						printf("%d ", hashdump->data);
					}
					printf("\n");
					continue;
				}

				i = bitmap_name_check(par1);
				if (i != bitmap_cnt){
					for (j = 0; j < bitmap_size(bit_var[i]); j++)
						printf("%d", bitmap_test(bit_var[i], j));
					printf("\n");
				}
			}
		}

		// list instructions
		else if (!strcmp(inst, "list_insert")) {
			num = sscanf(par, "%s %d %d", par1, &idx1, &val);
			if (num == 3){
				i = list_name_check(par1);
				if (i != list_cnt){
					struct list_item *newitem;
	
					newitem = (struct list_item*)malloc(sizeof(struct list_item));
					newitem->data = val;

					struct list_elem *before = list_begin(&list_var[i]);
					for (i = 0; i < idx1; i++)
						before = list_next(before);
					list_insert(before, &newitem->elem);
				}

			}
		}
		else if (!strcmp(inst, "list_splice")) {
			num = sscanf(par, "%s %d %s %d %d", par1, &idx1, par2, &idx2, &idx3);
			if (num == 5){
				i = list_name_check(par1);
				j = list_name_check(par2);
				if (i != list_cnt && j != list_cnt){
				struct list_elem *before = list_begin(&list_var[i]);
				struct list_elem *first = list_begin(&list_var[j]);
				struct list_elem *last = list_begin(&list_var[j]);
				int k;

				for (k = 0; k < idx1; k++)
					before = list_next(before);
				for (k = 0; k < idx2; k++)
					first = list_next(first);
				for (k = 0; k < idx3; k++)
					last = list_next(last);
				list_splice(before, first, last);
				}
			}
		}
		else if (!strcmp(inst, "list_push_front")) {
			num = sscanf(par, "%s %d", par1, &val);
			if (num == 2){
				i = list_name_check(par1);
				if (i != list_cnt){
					struct list_item *newitem;
					newitem = (struct list_item*)malloc(sizeof(struct list_item));
					newitem->data = val;
					list_push_front(&list_var[i], &newitem->elem);
				}
			}
		}
		else if (!strcmp(inst, "list_push_back")) {
			num = sscanf(par, "%s %d", par1, &val);
			if (num == 2){
				i = list_name_check(par1);
				if (i != list_cnt){
					struct list_item *newitem;
					newitem = (struct list_item*)malloc(sizeof(struct list_item));
					newitem->data = val;
					list_push_back(&list_var[i], &newitem->elem);
				}
			}
		}
		else if (!strcmp(inst, "list_remove")) {
			num = sscanf(par, "%s %d", par1, &idx1);
			if (num == 2){
				i = list_name_check(par1);
				if (i != list_cnt){
					struct list_elem *delelem;
					delelem = list_begin(&list_var[i]);
					for (i = 0; i < idx1; i++)
						delelem = list_next(delelem);
					list_remove(delelem);
				}
			}
		}
		else if (!strcmp(inst, "list_pop_front")) {
			num = sscanf(par, "%s", par1);
			if (num == 1){
				i = list_name_check(par1); 
				if (i != list_cnt){
					struct list_elem *deltmp;
					deltmp = list_pop_front(&list_var[i]);
					free(deltmp);
				}
			}
		}
		else if (!strcmp(inst, "list_pop_back")) {
			num = sscanf(par, "%s", par1);
			if (num == 1){
				i = list_name_check(par1);
				if (i != list_cnt){
					struct list_elem *deltmp;
					deltmp = list_pop_back(&list_var[i]);
					free(deltmp);
				}
			}
		}
		else if (!strcmp(inst, "list_front")) {
			num = sscanf(par, "%s", par1);
			if (num == 1){
				i = list_name_check(par1);
				if (i != list_cnt){
					struct list_item *frontitem;
					frontitem = list_entry(list_front(&list_var[i]), struct list_item, elem);
					printf("%d\n", frontitem->data);
				}
			}
		}
		else if (!strcmp(inst, "list_back")) {
			num = sscanf(par, "%s", par1);
			if (num == 1){
				i = list_name_check(par1);
				if (i != list_cnt){
					struct list_item *backitem;
					backitem = list_entry(list_back(&list_var[i]), struct list_item, elem);
					printf("%d\n", backitem->data);
				}
			}
		}
		else if (!strcmp(inst, "list_size")) {
			num = sscanf(par, "%s", par1);
			if (num == 1){
				i = list_name_check(par1);
				if (i != list_cnt){
					size_t size;
					size = list_size(&list_var[i]);
					printf("%zu\n", size);
				}
			}
		}
		else if (!strcmp(inst, "list_empty")) {
			num = sscanf(par, "%s", par1);
			if (num == 1){
				i = list_name_check(par1);
				if (i != list_cnt){
					int tf;
					tf = list_empty(&list_var[i]);
					if (tf == 0)
						printf("false\n");
					else if (tf == 1)
						printf("true\n");
				}
			}
		}
		else if (!strcmp(inst, "list_reverse")) {
			num = sscanf(par, "%s", par1);
			if (num == 1){
				i = list_name_check(par1);
				if (i != list_cnt)
					list_reverse(&list_var[i]);
			}
		}
		else if (!strcmp(inst, "list_sort")) {
			num = sscanf(par, "%s", par1);
			if (num == 1){
				i = list_name_check(par1);
				if (i != list_cnt)
					list_sort(&list_var[i], list_less, NULL);
			}
		}
		else if (!strcmp(inst, "list_insert_ordered")) {
			num = sscanf(par, "%s %d", par1, &val);
			if (num == 2){
				i = list_name_check(par1);
				if (i != list_cnt){
					struct list_item *newitem;
					newitem = (struct list_item*)malloc(sizeof(struct list_item));
					newitem->data = val;
					list_insert_ordered(&list_var[i], &newitem->elem, list_less, NULL);
				}
			}

		}
		else if (!strcmp(inst, "list_unique")) {
			num = sscanf(par, "%s %s", par1, par2);
			if (num == 1){
				i = list_name_check(par1);
				if (i != list_cnt)
					list_unique(&list_var[i], NULL, list_less, NULL);
			}
			else if (num == 2){
				i = list_name_check(par1);
				j = list_name_check(par2);
				if (i != list_cnt && j != list_cnt)
					list_unique(&list_var[i], &list_var[j], list_less, NULL);
			}
		}
		else if (!strcmp(inst, "list_max")) {
			num = sscanf(par, "%s", par1);
			if (num == 1){
				i = list_name_check(par1);
				if (i != list_cnt){
					struct list_elem *maxelem;
					struct list_item *maxitem;
					maxelem = list_max(&list_var[i], list_less, NULL);
					maxitem = list_entry(maxelem, struct list_item, elem);
					printf("%d\n", maxitem->data);
				}
			}

		}
		else if (!strcmp(inst, "list_min")) {
			num = sscanf(par, "%s", par1);
			if (num == 1){
				i = list_name_check(par1);
				if (i != list_cnt){
					struct list_elem *minelem;
					struct list_item *minitem;
					minelem = list_min(&list_var[i], list_less, NULL);
					minitem = list_entry(minelem, struct list_item, elem);
					printf("%d\n", minitem->data);
				}
			}

		}
		else if (!strcmp(inst, "list_swap")){
			num = sscanf(par, "%s %d %d", par1, &idx1, &idx2);
			if (num == 3){
				i = list_name_check(par1);
				if (i != list_cnt){
					struct list_elem *elem1 = list_begin(&list_var[i]);
					struct list_elem *elem2 = list_begin(&list_var[i]);

					for (i = 0; i < idx1; i++)
						elem1 = list_next(elem1);
					for (i = 0; i < idx2; i++)
						elem2 = list_next(elem2);
					list_swap(elem1, elem2);
				}
			}
		}
		else if (!strcmp(inst, "list_shuffle")){
			num = sscanf(par, "%s", par1);
			if (num == 1){
				i = list_name_check(par1);
				if (i != list_cnt)
					list_shuffle(&list_var[i]);
			}
		}

		// hash instructions
		else if (!strcmp(inst, "hash_insert")){
			num = sscanf(par, "%s %d", par1, &val);
			if (num == 2){
				i = hash_name_check(par1);
				if (i != hash_cnt){
					struct hash_item *newitem;
					newitem = (struct hash_item*)malloc(sizeof(struct hash_item));
					newitem->data = val;
					hash_insert(&hash_var[i], &newitem->elem);
				}
			}
		}
		else if (!strcmp(inst, "hash_replace")){
			num = sscanf(par, "%s %d", par1, &val);
			if (num == 2){
				i = hash_name_check(par1);
				if (i != hash_cnt){
					struct hash_item *newitem;
					newitem = (struct hash_item*)malloc(sizeof(struct hash_item));
					newitem->data = val;
					hash_replace(&hash_var[i], &newitem->elem);
				}
			}
		}
		else if (!strcmp(inst, "hash_find")){
			num = sscanf(par, "%s %d", par1, &val);
			if (num == 2){
				i = hash_name_check(par1);
				if (i != hash_cnt){
					struct hash_elem *findelem;
					struct hash_item *finditem;

					finditem = (struct hash_item*)malloc(sizeof(struct hash_item));
					finditem->data = val;
					findelem = hash_find(&hash_var[i], &finditem->elem);
					if (findelem != NULL){
						struct hash_item *findresult;
						findresult = hash_entry(findelem, struct hash_item, elem);
						printf("%d\n", findresult->data);
					}
				}
			}

		}
		else if (!strcmp(inst, "hash_delete")){
			num = sscanf(par, "%s %d", par1, &val);
			if (num == 2){
				i = hash_name_check(par1);
				if (i != hash_cnt){
					struct hash_item *delitem;
					struct hash_elem *del;
					delitem = (struct hash_item*)malloc(sizeof(struct hash_item));
					delitem->data = val;
					del = hash_delete(&hash_var[i], &delitem->elem);
					free(delitem);
					free(del);
				}
			}

		}
		else if (!strcmp(inst, "hash_clear")){
			num = sscanf(par, "%s", par1);
			if (num == 1){
				i = hash_name_check(par1);
				if (i != hash_cnt){
					hash_clear(&hash_var[i], hash_destructor);
				}
			}
		}
		else if (!strcmp(inst, "hash_size")){
			num = sscanf(par, "%s", par1);
			if (num == 1){
				i = hash_name_check(par1);
				if (i != hash_cnt){
					size_t hashsize;
					printf("%zu\n", hash_size(&hash_var[i]));
				}
			}
		}
		else if (!strcmp(inst, "hash_empty")){
			num = sscanf(par, "%s", par1);
			if (num == 1){
				i = hash_name_check(par1);
				if (i != hash_cnt){
					boolval = hash_empty(&hash_var[i]);
					if (boolval == 1)
						printf("true\n");
					else if (boolval == 0)
						printf("false\n");
				}
			}
		}
		else if (!strcmp(inst, "hash_apply")){
			num = sscanf(par, "%s %s", par1, par2);
			if (num == 2){
				i = hash_name_check(par1);
				if (i != hash_cnt){
					if (!strcmp(par2, "square"))
						hash_apply(&hash_var[i], hash_square);
					else if (!strcmp(par2, "triple"))
						hash_apply(&hash_var[i], hash_triple);
				}
			}

		}

		// bitmap instructions
		else if (!strcmp(inst, "bitmap_size")){
			num = sscanf(par, "%s", par1);
			if (num == 1){
				i = bitmap_name_check(par1);
				if (i != bitmap_cnt)
					printf("%zu\n", bitmap_size(bit_var[i]));
			}
		}
		else if (!strcmp(inst, "bitmap_set")){
			num = sscanf(par, "%s %d %s", par1, &idx1, par2);
			if (num == 3){
				i = bitmap_name_check(par1);
				if (i != bitmap_cnt){
					if (!strcmp(par2, "true"))
						boolval = 1;
					else if (!strcmp(par2, "false"))
						boolval = 0;
					bitmap_set(bit_var[i], idx1, boolval);
				}
			}
		}
		else if (!strcmp(inst, "bitmap_mark")){
			num = sscanf(par, "%s %d", par1, &idx1);
			if (num == 2){
				i = bitmap_name_check(par1);
				if (i != bitmap_cnt)
					bitmap_mark(bit_var[i], idx1);
			}
		}
		else if (!strcmp(inst, "bitmap_reset")){
			num = sscanf(par, "%s %d", par1, &idx1);
			if (num == 2){
				i = bitmap_name_check(par1);
				if (i != bitmap_cnt)
					bitmap_reset(bit_var[i], idx1);
			}
		}
		else if (!strcmp(inst, "bitmap_flip")){
			num = sscanf(par, "%s %d", par1, &idx1);
			if (num == 2){
				i = bitmap_name_check(par1);
				if (i != bitmap_cnt)
					bitmap_flip(bit_var[i], idx1);
			}
		}
		else if (!strcmp(inst, "bitmap_test")){
			num = sscanf(par, "%s %d", par1, &idx1);
			if (num == 2){
				i = bitmap_name_check(par1);
				if (i != bitmap_cnt){
					boolval = bitmap_test(bit_var[i], idx1);
					if (boolval == 0)
						printf("false\n");
					else if (boolval == 1)
						printf("true\n");
				}
			}
		}
		else if (!strcmp(inst, "bitmap_set_all")){
			num = sscanf(par, "%s %s", par1, par2);
			if (num == 2){
				i = bitmap_name_check(par1);
				if (i != bitmap_cnt){
					if (!strcmp(par2, "true"))
						boolval = 1;
					else if (!strcmp(par2, "false"))
						boolval = 0;
					bitmap_set_all(bit_var[i], boolval);
				}
			}
		}
		else if (!strcmp(inst, "bitmap_set_multiple")){
			num = sscanf(par, "%s %d %d %s", par1, &idx1, &val, par2);
			if (num == 4){
				i = bitmap_name_check(par1);
				if (i != bitmap_cnt){
					if (!strcmp(par2, "true"))
						boolval = 1;
					else if (!strcmp(par2, "false"))
						boolval = 0;
					bitmap_set_multiple(bit_var[i], idx1, val, boolval);
				}
			}
		}
		else if (!strcmp(inst, "bitmap_count")){
			num = sscanf(par, "%s %d %d %s", par1, &idx1, &val, par2);
			if (num == 4){
				i = bitmap_name_check(par1);
				if (i != bitmap_cnt){
					size_t cnt_result;
					if (!strcmp(par2, "true"))
						boolval = 1;
					else if (!strcmp(par2, "false"))
						boolval = 0;
					cnt_result = bitmap_count(bit_var[i], idx1, val, boolval);
					printf("%zu\n", cnt_result);
				}
			}
		}
		else if (!strcmp(inst, "bitmap_contains")){
			num = sscanf(par, "%s %d %d %s", par1, &idx1, &val, par2);
			if (num == 4){
				i = bitmap_name_check(par1);
				if (i != bitmap_cnt){
					int bool_result;
					if (!strcmp(par2, "true"))
						boolval = 1;
					else if (!strcmp(par2, "false"))
						boolval = 0;
					bool_result = bitmap_contains(bit_var[i], idx1, val, boolval);
					if (bool_result)
						printf("true\n");
					else if (!bool_result)
						printf("false\n");
				}
			}
		}
		else if (!strcmp(inst, "bitmap_any")){
			num = sscanf(par, "%s %d %d", par1, &idx1, &val);
			if (num == 3){
				i = bitmap_name_check(par1);
				if (i != bitmap_cnt){
					boolval = bitmap_any(bit_var[i], idx1, val);
					if (boolval)
						printf("true\n");
					else if (!boolval)
						printf("false\n");
				}
			}
		}
		else if (!strcmp(inst, "bitmap_none")){
			num = sscanf(par, "%s %d %d", par1, &idx1, &val);
			if (num == 3){
				i = bitmap_name_check(par1);
				if (i != bitmap_cnt){
					boolval = bitmap_none(bit_var[i], idx1, val);
					if (boolval)
						printf("true\n");
					else if (!boolval)
						printf("false\n");
				}
			}
		}
		else if (!strcmp(inst, "bitmap_all")){
			num = sscanf(par, "%s %d %d", par1, &idx1, &val);
			if (num == 3){
				i = bitmap_name_check(par1);
				if (i != bitmap_cnt){
					boolval = bitmap_all(bit_var[i], idx1, val);
					if (boolval)
						printf("true\n");
					else if (!boolval)
						printf("false\n");
				}
			}
		}
		else if (!strcmp(inst, "bitmap_scan")){
			num = sscanf(par, "%s %d %d %s", par1, &idx1, &val, par2);
			if (num == 4){
				i = bitmap_name_check(par1);
				if (i != bitmap_cnt){
					unsigned int scan_idx;
					if (!strcmp(par2, "true"))
						boolval = 1;
					else if (!strcmp(par2, "false"))
						boolval = 0;

					scan_idx = bitmap_scan(bit_var[i], idx1, val, boolval);
					printf("%u\n", scan_idx);
				}
			}
		}
		else if (!strcmp(inst, "bitmap_scan_and_flip")){
			num = sscanf(par, "%s %d %d %s", par1, &idx1, &val, par2);
			if (num == 4){
				i = bitmap_name_check(par1);
				if (i != bitmap_cnt){
					unsigned int scan_idx;
					if (!strcmp(par2, "true"))
						boolval = 1;
					else if (!strcmp(par2, "false"))
						boolval = 0;
					
					scan_idx = bitmap_scan_and_flip(bit_var[i], idx1, val, boolval);
					printf("%u\n", scan_idx);
				}
			}
		}
		else if (!strcmp(inst, "bitmap_dump")){
			num = sscanf(par, "%s", par1);
			if (num == 1){
				i = bitmap_name_check(par1);
				if (i != bitmap_cnt)
					bitmap_dump(bit_var[i]);
			}
		}
		else if (!strcmp(inst, "bitmap_expand")){
			num = sscanf(par, "%s %d", par1, &val);
			if (num == 2){
				i = bitmap_name_check(par1);
				if (i != bitmap_cnt)
					bit_var[i] = bitmap_expand(bit_var[i], val);
				
			}
		}
		// quit
		else if (!strcmp(inst, "quit")) {
			break;
		}

	}
}

void editcmd(char* cmd, char* new, char* idx) {
	int i = 0, j = 0;

	cmd[(unsigned)strlen(cmd) - 1] = '\0';

	while (cmd[i] == ' ' || cmd[i] == '\t')
		i++;

	while (cmd[i] != ' ' && cmd[i] != '\0' && cmd[i] != '\t') {
		new[j] = cmd[i];
		i++;
		j++;
	}

	if (cmd[i] != '\0') {
		j = 0;
		while (cmd[i] == ' ' || cmd[i] == '\t')
			i++;
		while (cmd[i] != '\0') {
			idx[j] = cmd[i];
			i++;
			j++;
		}
	}
}

int list_name_check(char *par){
	for (int i = 0; i < list_cnt; i++){
		if (!strcmp(par, list_name[i]))
			return i;
	}

	return list_cnt;
}

int hash_name_check(char *par){
	for (int i = 0; i < hash_cnt; i++){
		if (!strcmp(par, hash_name[i]))
			return i;
	}

	return hash_cnt;
}

int bitmap_name_check(char *par){
	for (int i = 0; i < bitmap_cnt; i++){
		if (!strcmp(par, bitmap_name[i]))
			return i;
	}

	return bitmap_cnt;
}

bool list_less(const struct list_elem *a, const struct list_elem *b, void *aux){
	struct list_item *a_item;
	struct list_item *b_item;

	a_item = list_entry(a, struct list_item, elem);
	b_item = list_entry(b, struct list_item, elem);

	if (a_item->data < b_item->data)
		return true;
	else
		return false;
}

void list_swap(struct list_elem *a, struct list_elem *b){
	struct list_item *aitem;
	struct list_item *bitem;
	int tmpdata;

	aitem = list_entry(a, struct list_item, elem);
	bitem = list_entry(b, struct list_item, elem);

	tmpdata = aitem->data;
	aitem->data = bitem->data;
	bitem->data = tmpdata;
}

void list_shuffle(struct list *list){
	int idx1, idx2, shuffle_num;
	struct list_elem *a;
	struct list_elem *b;

	srand(time(NULL));

	shuffle_num = rand() % 20;

	for (int j = 0; j < shuffle_num; j++){
		idx1 = rand() % list_size(list);
		idx2 = rand() % list_size(list);

		if (idx1 == idx2)
			continue;

		a = list_begin(list);
		b = list_begin(list);
		for (int i = 0; i < idx1; i++)
			a = list_next(a);
		for (int i = 0; i < idx2; i++)
			b = list_next(b);
		list_swap(a, b);
	}
}

unsigned hash_hash(const struct hash_elem *e, void *aux){
	struct hash_item *item;
	item = hash_entry(e, struct hash_item, elem);

	int value = item->data;
	unsigned result = hash_int(value);

	return result;
}

bool hash_less(const struct hash_elem *a, const struct hash_elem *b, void *aux){
	struct hash_item *aitem;
	struct hash_item *bitem;

	aitem = hash_entry(a, struct hash_item, elem);
	bitem = hash_entry(b, struct hash_item, elem);

	if (aitem->data < bitem->data)
		return true;
	else
		return false;
}

void hash_destructor(struct hash_elem *e, void *aux){
	struct hash_item *delitem;

	delitem = hash_entry(e, struct hash_item, elem);
	free(delitem);
}

void hash_square(struct hash_elem *e, void *aux){
	struct hash_item *square;

	square = hash_entry(e, struct hash_item, elem);
	int sqdata = square->data;
	square->data = sqdata * sqdata;
}

void hash_triple(struct hash_elem *e, void *aux){
	struct hash_item *triple;

	triple = hash_entry(e, struct hash_item, elem);
	int tridata = triple->data;
	triple->data = tridata * tridata * tridata;
}

unsigned hash_int_2(int i){
	double dtmp;
	int itmp;
	dtmp = (double)i * 0.71523183;
	itmp = (int)dtmp;

	if (itmp < 0)
		itmp--;

	dtmp -= itmp;
	dtmp *= 4;
	i = (int)dtmp;

	return hash_bytes(&i, sizeof i);
}

struct bitmap *bitmap_expand(struct bitmap *bitmap, int size){
	size_t tmpcnt;
	int idx1 = - 1, idx2 = -1, idx = -1, i;
	struct bitmap *expand;
	bool cur, pre;

	tmpcnt = bitmap_size(bitmap);
	expand = bitmap_create(tmpcnt + size);
	
	for (i = 0; i < tmpcnt; i++){
		cur = bitmap_test(bitmap, i);
		if (cur != pre){
			if (cur == 1)
				idx1 = i;
			else 
				idx2 = i;
		}

		if (cur == 1 && i == tmpcnt - 1)
			idx2 = i + 1;

		if (idx != idx2)
			bitmap_set_multiple(expand, idx1, idx2 - idx1, true);
		pre = cur;
		idx = idx2;
	}

	return expand;
}
